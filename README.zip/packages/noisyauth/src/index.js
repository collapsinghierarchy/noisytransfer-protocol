// Public, stable entry points (unchanged behavior).
export { createAuthSender }   from "./sender.js";
export { createAuthReceiver } from "./receiver.js";